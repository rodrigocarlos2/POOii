
public class Path {
	
	String path;
	double distanceTotal;

}
