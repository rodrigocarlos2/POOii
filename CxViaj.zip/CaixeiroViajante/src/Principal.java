
import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
	
	static int begin, end;
	public static ArrayList<Integer> values = new ArrayList();
	public static Scanner ent = new Scanner(System.in);
	public static ArrayList<Path> paths = new ArrayList();
	
	public static void permutation(String str){
	    permutation("", str);
	}

	private static void permutation(String prefix, String str){
		
	    int n = str.length();
	    
	    if (n == 0){
	    	String tmp2 = begin+prefix+end;
	    	//System.out.println(tmp2);
	    	Path tmp = new Path();
	    	tmp.path = tmp2;
	    	tmp.distanceTotal = 0;
	    	paths.add(tmp);
	    }
	    
	    else {
	        for (int i = 0; i < n; i++)
	            permutation(prefix + str.charAt(i), str.substring(0, i) + str.substring(i+1, n));
	    }
	}
	
	private static int readSize(){
		
		int r;
		
		System.out.println("Write the number: ");
		
		r = ent.nextInt();
		
		return r;
		
		
	}
	
	public static void main(String args[]){
		
		int n;
		
		do{
			n = readSize();
		}while(n<1 || n>9);
		// Accept only n>0 and n<10
		
		for(int i=0; i<n; i++){
			values.add(i);
		}
		
		begin = (int)values.get(0);
		end = (int)values.get(0);
		// Home - Travelling Salesman
		
		String cities = new String();
		
		if(n>1){
			cities = values.get(1).toString();
		}
		
		for(int i=2; i<values.size(); i++){
			String tmp = values.get(i).toString();
			cities = cities+tmp;
		}
		
		double distances[][] = new double[n][n];
		// Create the matriz distances | adjacency
		
		for(int i=0; i<n; i++){
			
			for(int j=0; j<n; j++){
				
				if(i!=j){
				
					System.out.println("Write the distance between "+i+" and "+j+": ");
					distances[i][j] = ent.nextDouble();
				
				}
			}
			
		}
		
		permutation(cities);
		
		System.out.println("Paths");
		
		double distance=0;
		double smallerDistance;
		
		int last = 0;
		
		for(int i=0; i<paths.size(); i++){
			
			distance=0;
			int j;
			String path = new String();
			path = paths.get(i).path;
			
			//System.out.println(path);
			
			for(j=0; j<path.length()-2; j++){
				
				if((j+1)<path.length()){
					
					char c1 = path.charAt(j);
					char c2 = path.charAt(j+1);
					
					int v1 = Character.getNumericValue(c1);
					int v2 = Character.getNumericValue(c2);
					
					if(distances[v1][v2]!=-1){
						distance = distance+distances[v1][v2];
						//System.out.println("Connection: "+v1+" - "+(v2));
						//System.out.println("Distance: "+distances[v1][v2]);
					}
					else{
						distance = -1;
						break;
					}
					
					last = v2;
					
				}
				
			}
			
			if(distance!=-1){
				//System.out.println("Connection: "+last+" - 0:");
				distance = distance+distances[last][0];
			}
			// Return for home
			
			paths.get(i).distanceTotal = distance;
			
		}
		
		for(int i=0; i<paths.size(); i++){
			
			//System.out.println("Path: "+paths.get(i).path+" - Distance: "+paths.get(i).distanceTotal);
			
		}
		
		smallerDistance=-1;
		
		for(int i=0; i<paths.size(); i++){
			
			if(paths.get(i).distanceTotal!=-1){
			
				smallerDistance = paths.get(i).distanceTotal;
				break;
			
			}
		}
		
		for(int i=1; i<paths.size(); i++){
			
			if(paths.get(i).distanceTotal<smallerDistance && paths.get(i).distanceTotal!=-1){
				
				smallerDistance = paths.get(i).distanceTotal; 
				
			}
			
		}
		
		System.out.println("Solution");
		
		for(int i=1; i<paths.size(); i++){
			
			if(paths.get(i).distanceTotal==smallerDistance){
				
				System.out.println("Path: "+paths.get(i).path+" - Distance: "+smallerDistance); 
				
			}
			
		}
		
	}

}