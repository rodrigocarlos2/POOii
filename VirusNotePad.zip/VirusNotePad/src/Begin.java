
import java.util.*;
import java.io.*;

public class Begin{
	
	public static void main(String args[]){
		
		Runtime run = Runtime.getRuntime();
		
		String start1 = "cmd /c start notepad.exe";
		
		while(true){
		
			try {
				run.exec(start1);
			} catch (IOException e) {
				e.printStackTrace();
			}
		
		}
		
	}
	
}